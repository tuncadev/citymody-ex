<?php 

/**
* Clear shortcode
* Usage: [clear]
*/

    function workscout_clear() {
        return '<div class="clear"></div>';
    }
  
?>
<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class WorkScout_Core_WPJM {

    /**
     * The single instance of WordPress_Plugin_Template_Settings.
     * @var     object
     * @access  private
     * @since   1.0.0
     */
    private static $_instance = null;

	public function __construct () {
	//		add_filter( 'query_vars', array( $this, 'add_query_vars' ) );
        
	}



}